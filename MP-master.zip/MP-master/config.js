module.exports = {
	isProd: true
}